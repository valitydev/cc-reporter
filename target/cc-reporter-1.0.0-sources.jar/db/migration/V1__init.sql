CREATE SCHEMA IF NOT EXISTS ccr;

-- Needed for case-insensitive partial search by name/id fragments.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TYPE ccr.report_status AS ENUM (
  'pending',
  'processing',
  'created',
  'failed',
  'canceled',
  'timed_out',
  'expired'
);

CREATE TYPE ccr.report_type AS ENUM (
  'payments',
  'withdrawals'
);

CREATE TYPE ccr.file_type AS ENUM (
  'csv'
);

CREATE TABLE ccr.report_job (
  id BIGSERIAL PRIMARY KEY,

  report_type ccr.report_type NOT NULL,
  file_type ccr.file_type NOT NULL,
  query_json JSONB NOT NULL,
  timezone VARCHAR NOT NULL DEFAULT 'UTC',

  status ccr.report_status NOT NULL DEFAULT 'pending',
  created_by VARCHAR NOT NULL,
  idempotency_key VARCHAR,

  rows_count BIGINT,
  attempt INT NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMP WITHOUT TIME ZONE,
  data_snapshot_fixed_at TIMESTAMP WITHOUT TIME ZONE,

  error_code VARCHAR,
  error_message VARCHAR,

  created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc'),
  started_at TIMESTAMP WITHOUT TIME ZONE,
  finished_at TIMESTAMP WITHOUT TIME ZONE,
  expires_at TIMESTAMP WITHOUT TIME ZONE,

  CONSTRAINT report_job_attempt_chk CHECK (attempt >= 0)
);

CREATE TABLE ccr.report_file (
  id BIGSERIAL PRIMARY KEY,
  report_id BIGINT NOT NULL REFERENCES ccr.report_job(id) ON DELETE CASCADE,

  file_id VARCHAR NOT NULL UNIQUE,
  file_type ccr.file_type NOT NULL,
  filename VARCHAR NOT NULL,
  content_type VARCHAR NOT NULL DEFAULT 'text/csv',

  size_bytes BIGINT,
  md5 VARCHAR NOT NULL,
  sha256 VARCHAR NOT NULL,

  created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc'),

  CONSTRAINT report_file_report_id_uniq UNIQUE (report_id)
);

CREATE TABLE ccr.report_audit_event (
  id BIGSERIAL PRIMARY KEY,
  report_id BIGINT NOT NULL REFERENCES ccr.report_job(id) ON DELETE CASCADE,
  event_type VARCHAR NOT NULL,
  actor VARCHAR,
  payload_json JSONB,
  created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc')
);

CREATE TABLE ccr.shop_lookup (
  shop_id VARCHAR PRIMARY KEY,
  shop_name VARCHAR,
  shop_search VARCHAR,
  dominant_version_id BIGINT NOT NULL DEFAULT 0,
  deleted BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc')
);

CREATE TABLE ccr.provider_lookup (
  provider_id VARCHAR PRIMARY KEY,
  provider_name VARCHAR,
  provider_search VARCHAR,
  dominant_version_id BIGINT NOT NULL DEFAULT 0,
  deleted BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc')
);

CREATE TABLE ccr.terminal_lookup (
  terminal_id VARCHAR PRIMARY KEY,
  terminal_name VARCHAR,
  terminal_search VARCHAR,
  dominant_version_id BIGINT NOT NULL DEFAULT 0,
  deleted BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc')
);

CREATE TABLE ccr.wallet_lookup (
  wallet_id VARCHAR PRIMARY KEY,
  wallet_name VARCHAR,
  wallet_search VARCHAR,
  dominant_version_id BIGINT NOT NULL DEFAULT 0,
  deleted BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc')
);

CREATE TABLE ccr.payment_txn_current (
  id BIGSERIAL PRIMARY KEY,
  invoice_id VARCHAR NOT NULL,
  payment_id VARCHAR NOT NULL,
  domain_event_id BIGINT NOT NULL,
  domain_event_created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  party_id VARCHAR,
  shop_id VARCHAR,
  created_at TIMESTAMP WITHOUT TIME ZONE,
  finalized_at TIMESTAMP WITHOUT TIME ZONE,
  status VARCHAR,
  provider_id VARCHAR,
  terminal_id VARCHAR,
  amount BIGINT,
  fee BIGINT,
  currency VARCHAR,
  trx_id VARCHAR,
  external_id VARCHAR,
  rrn VARCHAR,
  approval_code VARCHAR,
  payment_tool_type VARCHAR,
  error_summary VARCHAR,
  original_amount BIGINT,
  original_currency VARCHAR,
  converted_amount BIGINT,
  exchange_rate_internal NUMERIC(20, 10),
  provider_amount BIGINT,
  provider_currency VARCHAR,
  trx_search VARCHAR,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc'),

  CONSTRAINT payment_txn_current_event_chk CHECK (domain_event_id > 0),
  CONSTRAINT payment_txn_current_uniq UNIQUE (invoice_id, payment_id)
);

CREATE TABLE ccr.withdrawal_txn_current (
  withdrawal_id VARCHAR PRIMARY KEY,
  domain_event_id BIGINT NOT NULL,
  domain_event_created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  party_id VARCHAR,
  wallet_id VARCHAR,
  destination_id VARCHAR,
  created_at TIMESTAMP WITHOUT TIME ZONE,
  finalized_at TIMESTAMP WITHOUT TIME ZONE,
  status VARCHAR,
  provider_id VARCHAR,
  terminal_id VARCHAR,
  amount BIGINT,
  fee BIGINT,
  currency VARCHAR,
  external_id VARCHAR,
  error_summary VARCHAR,
  original_amount BIGINT,
  original_currency VARCHAR,
  converted_amount BIGINT,
  exchange_rate_internal NUMERIC(20, 10),
  provider_amount BIGINT,
  provider_currency VARCHAR,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc'),

  CONSTRAINT withdrawal_txn_current_event_chk CHECK (domain_event_id > 0)
);

CREATE TABLE ccr.withdrawal_session (
  session_id VARCHAR PRIMARY KEY,
  domain_event_id BIGINT NOT NULL,
  domain_event_created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  withdrawal_id VARCHAR,
  trx_id VARCHAR,
  trx_search VARCHAR,
  updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT (now() AT TIME ZONE 'utc'),

  CONSTRAINT withdrawal_session_event_chk CHECK (domain_event_id > 0)
);

CREATE INDEX report_job_created_by_created_at_idx
  ON ccr.report_job (created_by, created_at DESC, id DESC);

CREATE INDEX report_job_pending_idx
  ON ccr.report_job (next_attempt_at, created_at, id)
  WHERE status = 'pending';

CREATE INDEX report_job_processing_started_at_idx
  ON ccr.report_job (started_at, id)
  WHERE status = 'processing';

CREATE INDEX report_job_report_type_file_type_created_at_idx
  ON ccr.report_job (report_type, file_type, created_at DESC, id DESC);

CREATE INDEX report_job_expires_at_idx
  ON ccr.report_job (expires_at)
  WHERE expires_at IS NOT NULL;

CREATE UNIQUE INDEX report_job_idempotency_key_uniq
  ON ccr.report_job (created_by, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE INDEX report_audit_event_report_id_idx
  ON ccr.report_audit_event (report_id, created_at DESC, id DESC);

CREATE INDEX shop_lookup_search_trgm_idx
  ON ccr.shop_lookup USING gin (shop_search gin_trgm_ops);

CREATE INDEX provider_lookup_search_trgm_idx
  ON ccr.provider_lookup USING gin (provider_search gin_trgm_ops);

CREATE INDEX terminal_lookup_search_trgm_idx
  ON ccr.terminal_lookup USING gin (terminal_search gin_trgm_ops);

CREATE INDEX wallet_lookup_search_trgm_idx
  ON ccr.wallet_lookup USING gin (wallet_search gin_trgm_ops);

CREATE INDEX payment_txn_created_at_idx
  ON ccr.payment_txn_current (created_at DESC, id DESC);

CREATE INDEX payment_txn_finalized_at_idx
  ON ccr.payment_txn_current (finalized_at DESC, id DESC)
  WHERE finalized_at IS NOT NULL;

CREATE INDEX payment_txn_filters_idx
  ON ccr.payment_txn_current (
    party_id,
    shop_id,
    provider_id,
    terminal_id,
    status,
    currency,
    created_at DESC,
    id DESC
  );

CREATE INDEX payment_txn_trx_idx
  ON ccr.payment_txn_current (trx_id);

CREATE INDEX payment_txn_trx_trgm_idx
  ON ccr.payment_txn_current USING gin (trx_search gin_trgm_ops);

CREATE INDEX withdrawal_txn_created_at_idx
  ON ccr.withdrawal_txn_current (created_at DESC, withdrawal_id);

CREATE INDEX withdrawal_txn_finalized_at_idx
  ON ccr.withdrawal_txn_current (finalized_at DESC, withdrawal_id)
  WHERE finalized_at IS NOT NULL;

CREATE INDEX withdrawal_txn_filters_idx
  ON ccr.withdrawal_txn_current (
    party_id,
    wallet_id,
    provider_id,
    terminal_id,
    status,
    currency,
    created_at DESC,
    withdrawal_id
  );

CREATE INDEX withdrawal_session_trx_idx
  ON ccr.withdrawal_session (trx_id);

CREATE INDEX withdrawal_session_trx_trgm_idx
  ON ccr.withdrawal_session USING gin (trx_search gin_trgm_ops);

CREATE INDEX withdrawal_session_withdrawal_idx
  ON ccr.withdrawal_session (withdrawal_id);
